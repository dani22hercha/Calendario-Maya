package calendariomaya;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class CalendarioMaya {
    static Scanner texto = new Scanner (System.in);

    public static void main(String[] args) {
        File archivo = null;
        FileReader palabras = null;
        BufferedReader datos = null;
        
        try {
            archivo= new File ("C:\\Users\\Usuario\\Desktop\\CalendarioMaya.txt");
            palabras = new FileReader (archivo);
            datos= new BufferedReader(palabras);
            
            String linea;
            String entrada;            
            String d;
            int c=0;
            
            //Entrada
            while((linea=datos.readLine())!=null) {
                
                System.out.println(linea);
                String[] Datos = linea.split(" ");
                System.out.println("dia:"+Datos[0]); //Día
                System.out.println("mes:"+Datos[1]); //Mes
                System.out.println("año:"+Datos[2]); //Año
                
                String Haab[]={"pop", "no", "zip", "zotz", "tzec", "xul", "yoxkin", "mol", "chen", "yax", "zac", "ceh", "mac", "kankin", "muan", "pax", "koyab", "cumhu", "uayet"};
                String Tzolkin[]={"imix", "ik", "akbal", "kan", "chicchan", "cimi", "manik", "lamat", "muluk", "ok", "chuen", "eb", "ben", "ix", "mem", "cib", "caban", "eznab", "canac", "ahau"};

                System.out.println("Año Haab:");
                for(int i=0; i<Haab.length; i++){   //meses                    
                    System.out.print(Haab[i]+":");
                    if(i<Haab.length-1){
                        for(int j=0; j<20; j++){    //dias
                            d= String.valueOf(j);
                            if((Datos[1].equals(Haab[i]))  &&   (Datos[0].equals(d))){
                                c++;
                            }
                            if(Datos[1].equals(Haab[i])  &&   Datos[0].equals(d)){
                                System.out.print("->");                        
                            }
                            System.out.print(j+" ");
                        }
                    }
                    else{
                        for(int j=0; j<5; j++){//dias
                            System.out.print(j+" ");
                        }
                    }
                    System.out.println("");
                }
                System.out.println("C===="+c);
                
                /*
                System.out.println("\nAño Tzolkin:");
                for(int i=0; i<Tzolkin.length; i++){   //meses
                    System.out.print(Tzolkin[i]+":");   //dias
                    for(int j=0; j<20; j++){
                        System.out.print(j+" ");
                    }                
                    System.out.println("");
                }
                */
            }
            
        }
        
        catch (IOException e) {
            System.out.println("Error en los datos de entrada "+e);
        }
        catch(Exception e) {
            System.out.println("Error en los datos de entrada "+e);
        }
        
        finally {
            try {
                datos.close();
            }
            catch (IOException e) {
                System.out.println("Problema en el cierre del archivo "+e);
            }
        }
        
    }
    
}
